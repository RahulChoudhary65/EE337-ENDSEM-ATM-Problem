#include <at89c5131.h>
#include "endsem.h"

char S_str[6]= {0,0,0,0,0,0};   //String for Balance Sita
char G_str[6] = {0,0,0,0,0,0};  //String for Balance Gita
char n500_s[3]= {0,0,0};    // STRING FOR 500RS NOTE
char n100_s[3]= {0,0,0};    // STRING FOR 100RS NOTE

char password[5] = {0,0,0,0,0} ;   //PASSWORD ARRAY

//Main function

//-------------------------------------------------
void main(void)
{
		uart_init();            // Please finish this function in endsem.h 
	
    while (1)
    {
        unsigned char ch = 0;
				unsigned char am1 = 0;
				unsigned char am2 = 0;
				unsigned char pw0 = 0;
				unsigned char pw1 = 0;
				unsigned char pw2 = 0;
				unsigned char pw3 = 0;
				unsigned char pw4 = 0;
	
			
				unsigned int balance_Sita = 10000;
				unsigned int balance_Gita = 10000;
			
				unsigned int msb = 0;
				unsigned int lsb = 0;
			
				
				unsigned int final_w_count = 0;
				unsigned int note_500 = 0;
				unsigned int note_100 = 0;
			
				int_to_string(balance_Sita, S_str);
				int_to_string(balance_Gita, G_str);
			
										
				transmit_string("Press A for Account display and W for withdrawing cash\r\n");
				//initial state 
			
				//Receive a character
				ch = receive_char();
		
			if(ch == 'a' || ch == 'A'){	//Account Display
				
				unsigned char acc_number = 0;
				transmit_string("Hello, Please enter Account Number\r\n");
				
				acc_number = receive_char();
				
				if(acc_number == '1'){
					
					transmit_string("Account Holder: Sita\r\n");
					transmit_string("Account Balance: ");
					transmit_string(S_str);
					transmit_string("\r\n");
					
				}
				else if(acc_number == '2'){
					
					transmit_string("Account Holder: Gita\r\n");
					transmit_string("Account Balance: ");
					transmit_string(G_str);
					transmit_string("\r\n");
					
				}
				else{
					transmit_string("No such account, please enter valid details\r\n");
					
				}			

			}//Account display state ends here
			
			
			else{//Withdraw cash
					
					unsigned char number_W = 0;
				
					transmit_string("Withdraw state, enter account number\r\n");
				
					number_W = receive_char();
				
				if(number_W == '1'){
					
					transmit_string("Account Holder: Sita\r\n");
					transmit_string("Account Balance: ");
					transmit_string(S_str);
					transmit_string("\r\n");
					
					transmit_string("Enter Amount, in hundreds\r\n");
				
					am1 = receive_char();
					am2 = receive_char();
				
					am1 = am1 - 0x30;
					am2 = am2 - 0x30;
				
					transmit_string("Please enter password\r\n");
					
					pw0 = receive_char();
					pw1 = receive_char();
					pw2 = receive_char();
					pw3 = receive_char();
					pw4 = receive_char();
					
					if(pw0 == 'E' && pw1 == 'E' && pw2 == '3' && pw3 == '3' && pw4 == '7'){
						
							
					msb = am1;
					lsb = am2;
				
					msb = msb*1000;
					lsb = lsb*100;
				
					final_w_count = msb + lsb;
				
					note_500 = final_w_count/500;
					note_100 = (final_w_count%500)/100;
				
					balance_Sita = balance_Sita - final_w_count;
					int_to_string(balance_Sita, S_str);
				
					int_to_string_2(note_500, n500_s);
					int_to_string_2(note_100, n100_s);
				
					transmit_string("Remaining Balance: ");
					transmit_string(S_str);
					transmit_string("\r\n");
				
				
					transmit_string("500 Notes: ");
					transmit_string(n500_s);
				
					transmit_string(", 100 Notes: ");
					transmit_string(n100_s);
							
					transmit_string("\r\n");
				}
					else{
						continue;
					}
					
					
				}
				else if(number_W == '2'){
					
					transmit_string("Account Holder: Gita\r\n");
					transmit_string("Account Balance: ");
					transmit_string(G_str);
					transmit_string("\r\n");
					
					transmit_string("Enter Amount, in hundreds\r\n");
				
				
					am1 = receive_char();
					am2 = receive_char();
				
					am1 = am1 - 0x30;
					am2 = am2 - 0x30;
					
					transmit_string("Please enter password\r\n");
					
					pw0 = receive_char();
					pw1 = receive_char();
					pw2 = receive_char();
					pw3 = receive_char();
					pw4 = receive_char();
					
					if(pw0 == 'U' && pw1 == 'P' && pw2 == 'L' && pw3 == 'A' && pw4 == 'B'){
				
					msb = am1;
					lsb = am2;
				
					msb = msb*1000;
					lsb = lsb*100;
				
					final_w_count = msb + lsb;
				
					note_500 = final_w_count/500;
					note_100 = (final_w_count%500)/100;
				
					balance_Gita = balance_Gita - final_w_count;
					int_to_string(balance_Gita, G_str);
				
					int_to_string_2(note_500, n500_s);
					int_to_string_2(note_100, n100_s);
				
					transmit_string("Remaining Balance: ");
					transmit_string(G_str);
					transmit_string("\r\n");
				
				
					transmit_string("500 Notes: ");
					transmit_string(n500_s);
				
					transmit_string(", 100 Notes: ");
					transmit_string(n100_s);
							
					transmit_string("\r\n");
					
				}
					else{
						continue;
					}
					
				}
				else{
					transmit_string("No such account, please enter valid details\r\n");
					
					continue;
					
				}
				
						
			}//Withdraw state ends here
				
				
			
    }//while loop ends here
		
}//main function ends here


